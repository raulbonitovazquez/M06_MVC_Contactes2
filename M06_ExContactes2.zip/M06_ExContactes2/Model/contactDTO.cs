﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Model
{
    public class contactDTO
    {
        public int contacteId { get; set; }
        public string nom { get; set; }
        public string cognoms { get; set; }

        public contactDTO(int id, string nom, string cognoms)
        {
            this.contacteId = id;
            this.nom = nom;
            this.cognoms = cognoms;


        }

        public contactDTO(contacte c)
        {
            this.contacteId = c.contacteId;
            this.nom = c.nom;
            this.cognoms = c.cognoms;
        }

        public contactDTO ContacteDTOFromRow(DataGridViewCellCollection row)
        {
            return new contactDTO((int)row["Id"].Value, (string)row["Nom"].Value, (string)row["Cognoms"].Value);
        }

    }
}