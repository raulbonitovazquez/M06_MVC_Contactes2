﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Model
{
    public class telefonDTO
    {
        public int telfId { get; set; }
        public string telefon { get; set; }
        public string tipus { get; set; }

        public telefonDTO(int id, string telefon, string tipus)
        {
            this.telfId = id;
            this.telefon = telefon;
            this.tipus = tipus;


        }

        public telefonDTO(telefon t)
        {
            this.telfId = t.telId;
            this.telefon = t.telefon1;
            this.tipus = t.tipus;
        }

    }
}
