﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Model
{
    public class Repository
    {
        Contactes2Entities ce;

        public Repository()
        {
            ce = new Contactes2Entities();
           
        }

        public List<contactDTO> contactes()
        {
            List<contactDTO> li = ce.contactes.ToList().Select(c => new contactDTO(c)).ToList();
            return li;
        }

        public contactDTO ContacteDTOFromRow(DataGridViewCellCollection row)
        {
            return new contactDTO((int)row["contacteId"].Value, (string)row["nom"].Value, (string)row["cognoms"].Value);
        }

        public List<telefonDTO> ContactesTelfs(int id)
        {
            List<telefonDTO> li = ce.telefons.Where(c => c.contacteId == id).ToList().Select(telf => new telefonDTO(telf)).ToList();
            return li;

        }

        public telefonDTO TelefonDTOFromRow(DataGridViewCellCollection row)
        {
            return new telefonDTO((int)row["telfId"].Value, (string)row["telefon"].Value, (string)row["tipus"].Value);
        }

        public void afegirContacte(string nom, string cognoms)
        {
            contacte c = new contacte();
            c.nom = nom;
            c.cognoms = cognoms;
            ce.contactes.Add(c);
            ce.SaveChanges();
            
        }
        public void modificarContacte(int id, string nom, string cognoms)
        {
            contacte c = ce.contactes.Where(x => x.contacteId == id).SingleOrDefault();
            c.nom = nom;
            c.cognoms = cognoms;
            ce.SaveChanges();
        }
        public void eliminarContacte(int id)
        {
            List<telefon> liT = ce.telefons.Where(x => x.contacteId == id).ToList();
            liT.Clear();


            List<email> liE = ce.emails.Where(x => x.contacteId == id).ToList();
            liE.Clear();
            contacte c = ce.contactes.Where(x => x.contacteId == id).SingleOrDefault();
            ce.contactes.Remove(c);
            ce.SaveChanges();
        }

        public void afegirTelefon(int id, string num, string tipus)
        {
            telefon t = new telefon();
            t.contacteId = id;
            t.telefon1 = num;
            t.tipus = tipus;

            ce.telefons.Add(t);
            ce.SaveChanges();
        }
        public void modificarTelefon(int id, string num, string tipus)
        {
            telefon t = ce.telefons.Where(x => x.telId == id).SingleOrDefault();
            t.telefon1 = num;
            t.tipus = tipus;
            ce.SaveChanges();
        }
        public void esborrarTelefon(int id)
        {
            telefon t = ce.telefons.Where(x => x.telId == id).SingleOrDefault();
            ce.telefons.Remove(t);
            ce.SaveChanges();
        }
    }
}
