﻿namespace View
{
    partial class View1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.textBoxNom = new System.Windows.Forms.TextBox();
            this.textBoxNum = new System.Windows.Forms.TextBox();
            this.textBoxTipus = new System.Windows.Forms.TextBox();
            this.buttonAfegirCont = new System.Windows.Forms.Button();
            this.buttonModCont = new System.Windows.Forms.Button();
            this.buttonEsbCont = new System.Windows.Forms.Button();
            this.buttonEsbNum = new System.Windows.Forms.Button();
            this.buttonModNum = new System.Windows.Forms.Button();
            this.buttonAfegirNum = new System.Windows.Forms.Button();
            this.textBoxCognoms = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Default;
            this.dataGridView1.Location = new System.Drawing.Point(5, 12);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(302, 347);
            this.dataGridView1.TabIndex = 0;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(313, 12);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(427, 224);
            this.dataGridView2.TabIndex = 1;
            // 
            // textBoxNom
            // 
            this.textBoxNom.Location = new System.Drawing.Point(5, 365);
            this.textBoxNom.Name = "textBoxNom";
            this.textBoxNom.Size = new System.Drawing.Size(121, 20);
            this.textBoxNom.TabIndex = 2;
            // 
            // textBoxNum
            // 
            this.textBoxNum.Location = new System.Drawing.Point(352, 242);
            this.textBoxNum.Name = "textBoxNum";
            this.textBoxNum.Size = new System.Drawing.Size(174, 20);
            this.textBoxNum.TabIndex = 3;
            // 
            // textBoxTipus
            // 
            this.textBoxTipus.Location = new System.Drawing.Point(532, 242);
            this.textBoxTipus.Name = "textBoxTipus";
            this.textBoxTipus.Size = new System.Drawing.Size(190, 20);
            this.textBoxTipus.TabIndex = 4;
            // 
            // buttonAfegirCont
            // 
            this.buttonAfegirCont.Location = new System.Drawing.Point(5, 391);
            this.buttonAfegirCont.Name = "buttonAfegirCont";
            this.buttonAfegirCont.Size = new System.Drawing.Size(75, 23);
            this.buttonAfegirCont.TabIndex = 5;
            this.buttonAfegirCont.Text = "Afegir";
            this.buttonAfegirCont.UseVisualStyleBackColor = true;
            // 
            // buttonModCont
            // 
            this.buttonModCont.Location = new System.Drawing.Point(116, 391);
            this.buttonModCont.Name = "buttonModCont";
            this.buttonModCont.Size = new System.Drawing.Size(75, 23);
            this.buttonModCont.TabIndex = 6;
            this.buttonModCont.Text = "Modificar";
            this.buttonModCont.UseVisualStyleBackColor = true;
            // 
            // buttonEsbCont
            // 
            this.buttonEsbCont.Location = new System.Drawing.Point(232, 391);
            this.buttonEsbCont.Name = "buttonEsbCont";
            this.buttonEsbCont.Size = new System.Drawing.Size(75, 23);
            this.buttonEsbCont.TabIndex = 7;
            this.buttonEsbCont.Text = "Esborrar";
            this.buttonEsbCont.UseVisualStyleBackColor = true;
            // 
            // buttonEsbNum
            // 
            this.buttonEsbNum.Location = new System.Drawing.Point(604, 268);
            this.buttonEsbNum.Name = "buttonEsbNum";
            this.buttonEsbNum.Size = new System.Drawing.Size(75, 23);
            this.buttonEsbNum.TabIndex = 10;
            this.buttonEsbNum.Text = "Esborrar";
            this.buttonEsbNum.UseVisualStyleBackColor = true;
            // 
            // buttonModNum
            // 
            this.buttonModNum.Location = new System.Drawing.Point(488, 268);
            this.buttonModNum.Name = "buttonModNum";
            this.buttonModNum.Size = new System.Drawing.Size(75, 23);
            this.buttonModNum.TabIndex = 9;
            this.buttonModNum.Text = "Modificar";
            this.buttonModNum.UseVisualStyleBackColor = true;
            // 
            // buttonAfegirNum
            // 
            this.buttonAfegirNum.Location = new System.Drawing.Point(377, 268);
            this.buttonAfegirNum.Name = "buttonAfegirNum";
            this.buttonAfegirNum.Size = new System.Drawing.Size(75, 23);
            this.buttonAfegirNum.TabIndex = 8;
            this.buttonAfegirNum.Text = "Afegir";
            this.buttonAfegirNum.UseVisualStyleBackColor = true;
            // 
            // textBoxCognoms
            // 
            this.textBoxCognoms.Location = new System.Drawing.Point(132, 365);
            this.textBoxCognoms.Name = "textBoxCognoms";
            this.textBoxCognoms.Size = new System.Drawing.Size(175, 20);
            this.textBoxCognoms.TabIndex = 11;
            // 
            // View1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(743, 450);
            this.Controls.Add(this.textBoxCognoms);
            this.Controls.Add(this.textBoxNom);
            this.Controls.Add(this.buttonEsbNum);
            this.Controls.Add(this.buttonModNum);
            this.Controls.Add(this.buttonAfegirNum);
            this.Controls.Add(this.buttonEsbCont);
            this.Controls.Add(this.buttonModCont);
            this.Controls.Add(this.buttonAfegirCont);
            this.Controls.Add(this.textBoxTipus);
            this.Controls.Add(this.textBoxNum);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Name = "View1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        
        #endregion

        public System.Windows.Forms.DataGridView dataGridView1;
        public System.Windows.Forms.DataGridView dataGridView2;
        public System.Windows.Forms.TextBox textBoxNom;
        public System.Windows.Forms.TextBox textBoxNum;
        public System.Windows.Forms.TextBox textBoxTipus;
        public System.Windows.Forms.Button buttonAfegirCont;
        public System.Windows.Forms.Button buttonModCont;
        public System.Windows.Forms.Button buttonEsbCont;
        public System.Windows.Forms.Button buttonEsbNum;
        public System.Windows.Forms.Button buttonModNum;
        public System.Windows.Forms.Button buttonAfegirNum;
        public System.Windows.Forms.TextBox textBoxCognoms;
    }
}

