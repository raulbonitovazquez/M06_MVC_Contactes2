﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using View;

namespace Controller
{
    public class Controller1
    {
        View1 v;
        Repository r;

        public Controller1()
        {
            populate();
            run();
        }

        public void run()
        {
            Application.Run(v);
        }

        private void populate()
        {
            v = new View1();
            r = new Repository();
             
            v.dataGridView1.DataSource = r.contactes();
            initListeners();

        }

        private void actualizar()
        {

            try
            {
                int selected = 0;

                if (v.dataGridView1.CurrentRow != null)
                {
                    selected = v.dataGridView1.CurrentRow.Index;
                }
                else
                {
                    v.textBoxCognoms.Text = "";
                    v.textBoxNom.Text = "";
                }
                
                v.dataGridView1.DataSource = r.contactes();
                v.dataGridView1.Rows[selected].Selected = true;
                selected = v.dataGridView2.CurrentRow.Index;
                DataGridViewCellCollection dv = v.dataGridView1.SelectedRows[0].Cells;
                contactDTO c = r.ContacteDTOFromRow(dv);
                v.dataGridView2.DataSource = r.ContactesTelfs(c.contacteId);
                v.dataGridView2.Rows[selected].Selected = true;


            }
            catch (Exception)
            {
            }
        }

        private void initListeners()
        {
            v.dataGridView1.SelectionChanged += DataGridView1_SelectionChanged;
            v.dataGridView2.SelectionChanged += DataGridView2_SelectionChanged;


            v.buttonAfegirCont.Click += ButtonAfegirCont_Click;
            v.buttonModCont.Click += ButtonModCont_Click;
            v.buttonEsbCont.Click += ButtonEsbCont_Click;


            v.buttonAfegirNum.Click += ButtonAfegirNum_Click;
            v.buttonModNum.Click += ButtonModNum_Click;
            v.buttonEsbNum.Click += ButtonEsbNum_Click;
        }

        private void ButtonModNum_Click(object sender, EventArgs e)
        {

            telefonDTO t = r.TelefonDTOFromRow(v.dataGridView2.SelectedRows[0].Cells);

            string num = v.textBoxNum.Text;
            string tipus = v.textBoxTipus.Text;
            r.modificarTelefon(t.telfId, num, tipus);
            actualizar();
        }

        private void ButtonEsbNum_Click(object sender, EventArgs e)
        {
            int id = r.TelefonDTOFromRow(v.dataGridView2.SelectedRows[0].Cells).telfId;
            r.esborrarTelefon(id);
            actualizar();
        }


        private void ButtonAfegirNum_Click(object sender, EventArgs e)
        {

            int id = r.ContacteDTOFromRow(v.dataGridView1.SelectedRows[0].Cells).contacteId;
            string num = v.textBoxNum.Text;
            string tipus = v.textBoxTipus.Text;

            r.afegirTelefon(id, num, tipus);
            actualizar();
        }

        private void ButtonEsbCont_Click(object sender, EventArgs e)
        {
            DataGridViewCellCollection dv = v.dataGridView1.SelectedRows[0].Cells;
            contactDTO c = r.ContacteDTOFromRow(dv);
            r.eliminarContacte(c.contacteId);
            actualizar();
        }

        private void ButtonModCont_Click(object sender, EventArgs e)
        {
            DataGridViewCellCollection dv = v.dataGridView1.SelectedRows[0].Cells;
            contactDTO c = r.ContacteDTOFromRow(dv);
            string nom = v.textBoxNom.Text;
            string cognoms = v.textBoxCognoms.Text;
            r.modificarContacte(c.contacteId, nom, cognoms);
            actualizar();

        }

        private void ButtonAfegirCont_Click(object sender, EventArgs e)
        {
            string nom = v.textBoxNom.Text;
            string cognoms = v.textBoxCognoms.Text;

            r.afegirContacte(nom, cognoms);
            actualizar();
        }

        private void DataGridView2_SelectionChanged(object sender, EventArgs e)
        {
            if (v.dataGridView2.SelectedRows.Count > 0)
            {
                DataGridViewCellCollection dv = v.dataGridView2.SelectedRows[0].Cells;
                telefonDTO t = r.TelefonDTOFromRow(dv);
                v.textBoxNum.Text = t.telefon;
                v.textBoxTipus.Text = t.tipus;
            }
        }

        private void DataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (v.dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewCellCollection dv = v.dataGridView1.SelectedRows[0].Cells;
                contactDTO c = r.ContacteDTOFromRow(dv);
                v.textBoxNom.Text = c.nom;
                v.textBoxCognoms.Text = c.cognoms;

                v.dataGridView2.DataSource = r.ContactesTelfs(c.contacteId);
            }
        }
    }
}
